﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour {

    Renderer render;


	// Use this for initialization
	void Start () {
        render = GetComponent<Renderer>();
        Visible = false;
	}
    private void OnTriggerEnter(Collider other)
    {
        GameObject.Find("CoinManager").GetComponent<coin_Manager>().StageClear();

    }
    public bool Visible
    {
        set { render.enabled = value; }
        get { return render.enabled; }
    }
    // Update is called once per frame
    void Update () {
		
	}
}
