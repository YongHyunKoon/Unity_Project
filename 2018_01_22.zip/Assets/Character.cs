﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Character : MonoBehaviour {
    float moveSpeed;
    Rigidbody rigidbody;

	// Use this for initialization
	void Start () {
        moveSpeed = 6.0f;
        rigidbody = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
        if(transform.position.y<-1.0f){
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
        Vector3 forward = Camera.main.transform.TransformDirection(Vector3.forward);
        forward.y = 0;
        forward = forward.normalized;

        Vector3 forwardForce = forward * Input.GetAxis("Vertical") * moveSpeed;
        rigidbody.AddForce(forwardForce);

        Vector3 right = Camera.main.transform.TransformDirection(Vector3.right);
        right.y = 0;
        right = right.normalized;

        Vector3 rightForce = right * Input.GetAxis("Horizontal") * moveSpeed;
        rigidbody.AddForce(rightForce);

	}
}
