﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_Manager : MonoBehaviour {
    [SerializeField] Transform target;

    float distance;
    float xSpeed, ySpeed;
    float yMinLimit, yMaxLimit;
    float x, y;

	// Use this for initialization
	void Start () {
        distance = 10.0f;
        xSpeed = 250.0f;
        ySpeed = 120.0f;
        yMinLimit = 5.0f;
        yMaxLimit = 80.0f;

        Vector3 angles = transform.eulerAngles;

        x = angles.x;
        y = angles.y;
	}
	
	// Update is called once per frame
	void Update () {
        if (!target)
        {

        }
	}
    public float ClampAngle(float angle, float min, float max)
    {
        if (angle < -360){
            angle += 360;
        }
        if(angle > 360)
        {
            angle -= 360;
        }
        return Mathf.Clamp(angle, min, max);
    }
}
