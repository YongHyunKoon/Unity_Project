﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class coin_Manager : MonoBehaviour {

    [SerializeField] Vector2    minMapPos;
    [SerializeField] Vector2    maxMapPos;
    [SerializeField] int        maxCoinCount;
    [SerializeField] GameObject coinPrefab;

    [SerializeField] Text textCoinCount;
    int curCoinCount;

    [SerializeField] AudioClip[] clips;
    AudioSource audioSource;
    Door clearDoor;
    // Use this for initialization
    void Start () {

        curCoinCount = maxCoinCount;
        textCoinCount.text = "Coin : " + curCoinCount + "/" + maxCoinCount;
        for (int i = 0; i < maxCoinCount; ++i)
        {
            CreateCoin(Random.Range(0, 2));

        }
        audioSource = GetComponent<AudioSource>();
        clearDoor = GameObject.Find("Door").GetComponent<Door>();
	}
	void CreateCoin(int _type)
    {
        GameObject clone = Instantiate(coinPrefab);
        Coin coin = clone.GetComponent<Coin>();

        float posX = Random.Range(minMapPos.x, maxMapPos.x);
        float posZ = Random.Range(minMapPos.y, maxMapPos.y);

        if(_type == 0)
        {
            coin.Init(new Vector3(posX, 0.65f, posZ));

        }
        else
        {
            float speed = Random.Range(150.0f, 1000.0f);
            coin.Init(new Vector3(posX, 0.65f, posZ), speed);
        }

    }
    public void Get_coin()
    {
        curCoinCount--;
        textCoinCount.text = "Coin : " + curCoinCount + "/" + maxCoinCount;

        if(curCoinCount <= 0)
        {
            clearDoor.Visible = true;
        }

        
    }
    public void StageClear()
    {
        if (!clearDoor.Visible) {
        return;
        }
        

        PlaySound(0);
        Time.timeScale = 0.0f;
        textCoinCount.text = "Game Clear";

    }
    void PlaySound(int _idx)
    {
        audioSource.Stop();
        audioSource.clip = clips[_idx];
        audioSource.Play();
    }
	// Update is called once per frame
	void Update () {
		
	}
}
