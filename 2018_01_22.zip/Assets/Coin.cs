﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour {

    [SerializeField] AudioClip audio;
    float speed;
    Vector3 rotate;
	// Use this for initialization
	void Start () {
        
        

	}
	public void Init(Vector3 _pos)
    {
        transform.position = _pos;
        speed = 150.0f;
    }
    public void Init(Vector3 _pos, float _speed)
    {
        transform.position = _pos;
        speed = Mathf.Clamp(_speed, 150.0f, 1000.0f);
    }
	// Update is called once per frame
	void Update () {
        Vector3 rotate = new Vector3(speed, 0.0f, 0.0f);
        transform.Rotate(rotate * Time.deltaTime);
	}
    private void OnTriggerEnter(Collider col)
    {
        GameObject.Find("CoinManager").GetComponent<coin_Manager>().Get_coin();
        AudioSource.PlayClipAtPoint(audio, transform.position);
        Destroy(gameObject);

    }
}
